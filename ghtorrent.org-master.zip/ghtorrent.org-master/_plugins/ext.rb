require 'jekyll/scholar'
require 'pp'
puts 'Loaded scholar'

