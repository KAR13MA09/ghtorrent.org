---
layout: page
title: Statistics 
tagline: 
---

<table class="table table-hover table-condensed">
  <thead>
    <tr>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><img src="api-resp.png" alt="API response time timeseries plot"></img></td>
      <td><img src="num-reqs.png" alt="Number of request per timeslot
      timeseries plot"></img></td>
      </tr>
      <tr>
      <td><img src="events-per-day.png " alt=""></img></td>
      <td><img src="resp-ip-boxplot.png" ></img></td>
      </tr>
  </tbody>
</table>
